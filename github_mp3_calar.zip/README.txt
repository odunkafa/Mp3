GITHUB MP3 ÇALAR

1. GitHub Pages aç.
2. index.html ve videolar.js dosyalarını aynı klasöre koy.
3. videolar.js dosyasını düzenleyerek YouTube videolarını ekle.
4. GitHub Pages adresini aç.

ÖNEMLİ:
- index.html dosyasına dokunmana gerek yok.
- Yeni video eklemek için sadece videolar.js dosyasını düzenle.
- YouTube linki olarak youtu.be veya youtube.com/watch?v=... kullanabilirsin.
- GitHub Pages HTTPS üzerinden yayınlandığı için YouTube iframe için yerel content:// dosyasından daha uygun bir ortamdır.
